# Design System Specification: Deploily LLC

## 1. Creative North Star: "The Fluid Architect"
The vision for this design system transcends the "generic SaaS" look. We are building **The Fluid Architect**: a visual language that feels engineered yet organic. By combining the precision of a high-tech deployment platform with the softness of a premium lifestyle brand, we move away from rigid boxes. 

Instead of a flat grid, we utilize **intentional asymmetry**, **tonal depth**, and **high-contrast typography scales**. The layout should feel like a curated editorial spread—breathing with massive whitespace, where elements float in a pressurized, clean environment. We aren't just building an interface; we are building a workspace that feels like a quiet, high-end studio.

---

## 2. Color & Surface Philosophy
We are moving beyond the "1px border" era. Interfaces that rely on lines feel cluttered and dated. This design system communicates structure through **Value Shifts** and **Atmospheric Depth**.

### The "No-Line" Rule
**Explicit Instruction:** Do not use 1px solid borders to section off content. 
*   **The Technique:** Boundaries must be defined solely through background color shifts. For example, a `surface_container_low` card sitting on a `surface` background provides enough contrast to be felt without being "seen." 

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers—like stacked sheets of frosted glass.
*   **Layer 0 (Base):** `surface` (#f7f9fb)
*   **Layer 1 (Sectioning):** `surface_container_low` (#f2f4f6)
*   **Layer 2 (Interactive Elements):** `surface_container_lowest` (#ffffff)
*   **Layer 3 (Floating/Pop-overs):** `surface_bright` (#f7f9fb) with Backdrop Blur.

### The "Glass & Gradient" Rule
To inject "soul" into the SaaS experience, primary actions and hero moments should utilize the **Signature Texture**:
*   **Primary Gradient:** A linear transition from `primary_container` (#0066ff) to `primary` (#0050cb) at a 135° angle.
*   **Glassmorphism:** For mobile navigation bars or floating action buttons, use `surface_container_lowest` at 80% opacity with a `20px` backdrop-blur. This integrates the component into the environment rather than "pasting" it on top.

---

## 3. Typography: Editorial Authority
We pair the technical precision of **Inter** with the geometric character of **Manrope** to create an authoritative, premium hierarchy.

*   **Display & Headlines (Manrope):** Large, bold, and airy. Use `display-lg` (3.5rem) for hero sections to create a "poster" feel. The tight letter-spacing (-0.02em) adds a premium, bespoke touch.
*   **Body & Labels (Newsreader):** Optimized for readability. Use `body-md` (0.875rem) as the workhorse for SaaS density.
*   **Contrast as Navigation:** Use `on_surface_variant` (#424656) for secondary metadata to push it back visually, allowing the primary headlines to command the user's focus.

---

## 4. Elevation & Depth
We eschew "Drop Shadows" in favor of **Ambient Occlusion**.

*   **Tonal Layering:** Depth is achieved by stacking. A `surface_container_highest` element on a `surface` background creates a "pressed" or "elevated" feel without a single pixel of shadow.
*   **Ambient Shadows:** When a shadow is required (e.g., a floating Modal), use a diffused blur: `0px 24px 48px rgba(0, 84, 214, 0.08)`. Notice the tint—we use a fraction of the `surface_tint` to mimic natural light refraction.
*   **The "Ghost Border" Fallback:** If a border is required for accessibility in input fields, use `outline_variant` (#c2c6d8) at **20% opacity**. It should be a suggestion of a line, not a constraint.

---

## 5. Component Logic

### Buttons (The Interaction Pillars)
*   **Primary:** Uses the **Signature Gradient** (Primary to Primary Container). Radius: `full`. No border.
*   **Secondary:** `surface_container_high` background with `on_surface` text. This feels like a soft tactile pebble.
*   **Tertiary:** Pure text using `primary` color, but with a wide `4` (1.4rem) horizontal padding that reveals a soft `surface_variant` ghost-pill on hover.

### Cards & Containers
*   **Rule:** Forbid divider lines.
*   **Separation:** Use the Spacing Scale `8` (2.75rem) to separate content blocks. 
*   **Style:** Radius `lg` (2rem). This extremely large radius communicates the "Modern/Vercel" aesthetic and makes the tech feel approachable.

### Input Fields
*   **State:** Default state is a `surface_container_highest` fill with no border. 
*   **Focus:** Transition the background to `surface_container_lowest` and add a 2px `primary` "ring" with a 4px offset.

### Signature Component: The "Deploy-Status" Chip
*   A custom component for Deploily. A `surface_container_lowest` pill with a soft `secondary` (Orange) glow effect using a `20px` spread shadow at 10% opacity to indicate "Live" or "Processing" status.

---

## 6. Do’s and Don’ts

### Do
*   **Do** use massive margins. If a section feels "done," add another `1.4rem` of whitespace.
*   **Do** use **asymmetric padding** in hero sections (e.g., more padding on the left than the right) to create an editorial, non-template look.
*   **Do** use `secondary` (Orange) sparingly as a "heat-map" color—only for critical alerts or high-conversion triggers.

### Don't
*   **Don't** use pure black (#000000). Always use `on_surface` (#191c1e) to maintain the soft, high-end feel.
*   **Don't** use the `none` or `sm` roundedness tokens for UI containers. This system lives in the `DEFAULT` (1rem) to `xl` (3rem) range.
*   **Don't** use standard "Grey" for shadows. Shadows must be tinted with the brand’s blue to keep the "light" in the design.